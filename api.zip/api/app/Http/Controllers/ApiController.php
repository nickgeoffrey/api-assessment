<?php

namespace App\Http\Controllers;

use App\Models\Guitar;
use Illuminate\Http\Request;
use Validator;

class ApiController extends Controller
{
    public function createGuitar(Request $request) {
        $validator = Validator::make($request->all(), [
            'brand_name' => 'required',
            'model_name' => 'required',
            'guitar_year' => 'required',
            'guitar_origin' => 'required'
        ]);
    
        if ($validator->fails()) {
            return response()->json(['message' => $validator->errors()], 403);
        } else {
            Guitar::create($request->all());
            return response()->json(['message' => 'Guitar created.'], 201);
        }
    }

    public function updateGuitar(Request $request, $id) {
        $guitars = Guitar::query();
        if ($guitars->where('id', $id)->exists()) {
            $guitar = $guitars->find($id);
            $guitar->brand_name = is_null($request->brand_name) ? $guitar->brand_name : $request->brand_name;
            $guitar->model_name = is_null($request->model_name) ? $guitar->model_name : $request->model_name;
            $guitar->guitar_year = is_null($request->guitar_year) ? $guitar->guitar_year : $request->guitar_year;
            $guitar->guitar_origin = is_null($request->guitar_origin) ? $guitar->guitar_origin : $request->guitar_origin;
            $guitar->save();
            return response()->json(['message' => 'Guitar updated.'], 200);
        } else {
            return response()->json(['message' => 'Guitar not found.'], 404);
        }
    }

    public function deleteGuitar($id) {
        $guitars = Guitar::query();
        if ($guitars->where('id', $id)->exists()) {
            $guitar = $guitars->find($id);
            $guitar->delete();
            return response()->json(['message' => 'Guitar deleted.'], 202);
        } else {
            return response()->json(['message' => 'Guitar not found.'], 404);
        }
    }

    public function getAllGuitars(Request $request)
    {
        $guitars = Guitars::query();
        if ($request->get('brand_name')) {
            $guitars->where('brand_name', '=', $request->get('brand_name'))->get();
        }
        return $guitars->get();
    }
    
    public function getGuitar($id) {
        $guitars = Guitar::query();
        if ($guitars->where('id', $id)->exists()) {
            $guitar = $guitars->where('id', $id)->get();
            return response($guitar, 200);
        } else {
            return response()->json(['message' => 'Guitar not found.'], 404);
        }
    }

    public function getAllShops(Request $request) {
        return Shop::with(['guitars'])->get();
    } 
}