<?php

namespace Tests\Feature;

use App\Models\Shop;
use App\Models\Guitar;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class ApiTest extends TestCase
{
    public function setUp(): void {
        parent::setUp();

        Shop::create([
            'id' => 1,
            'name' => "Rockshop",
            'city' => "Dunedin",
            'country' => "New Zealand"
        ]);

        Guitar::create([
            'brand_name' => "Fender",
            'model_name' => "Stratocaster",
            'guitar_year' => "1966",
            'guitar_origin' => "USA",
            'shop_id' => 1
        ]);
    }

    public function testPOSTGuitars()
    {
        $payload = [
            'brand_name' => "Fender",
            'model_name' => "Stratocaster",
            'guitar_year' => "1966",
            'guitar_origin' => "USA",
            'shop_id' => 1
        ];

        $response = $this->post('/api/guitars', $payload);
        $response
            ->assertStatus(201)
            ->assertJson([
                "message" => "Guitar created."
            ]);
    }

    // public function testUpdateGuitars()
    // {
    //     $payload = [
    //         'brand_name' => "Fender",
    //         'model_name' => "Stratocaster",
    //         'guitar_year' => "1976",
    //     ];

    //     $response = $this->put('/api/guitars/1', $payload);
    //     $response
    //         ->assertStatus(200)
    //         ->assertJson([
    //             "message" => "Guitar updated."
    //         ]);
    // }

    // public function testGETGuitars()
    // {
    //     $response = $this->get('/api/guitars');
    //     $response
    //         ->assertStatus(200)
    //         ->assertJsonStructure(
    //             [
    //                 '*' => [
    //                     'id',
    //                     'brand_name',
    //                     'model_name',
    //                     'guitar_year',
    //                     'guitar_origin'
    //                 ]
    //             ]
    //         );
    // }

    // public function testGETGuitar()
    // {
    //     $response = $this->get('/api/guitars/2');
    //     $response
    //         ->assertStatus(200)
    //         ->assertJsonFragment([
    //             'brand_name' => 'Fender',
    //             'model_name' => 'Telecaster'
    //         ]);
    // }

    // public function testDELETEGuitar()
    // {
    //     $response = $this->delete('/api/guitars/1');
    //     $response
    //         ->assertStatus(202)
    //         ->assertJson([
    //             "message" => "Guitar deleted."
    //         ]);
    // }

    // public function testDELETEGuitarNotFound()
    // {
    //     $response = $this->delete('/api/guitars/2');
    //     $response
    //         ->assertStatus(404)
    //         ->assertJson([
    //             "message" => "Guitar not found."
    //         ]);
    // }
}
