<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Guitar extends Model
{
    use HasFactory;

    protected $table = 'guitars';

    protected $fillable = ['brand_name', 'model_name', 'guitar_year', 'guitar_origin'];
}

