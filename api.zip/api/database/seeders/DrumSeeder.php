<?php

namespace Database\Seeders;

use App\Models\Drum;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;

class DrumSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run() {
        $json_file = File::get('database/data/drum-data.json');
        DB::table('drums')->delete();
        $data = json_decode($json_file);
        foreach ($data as $obj) {
            Drum::create(array(
                'brand_name' => $obj->brand_name,
                'model_name' => $obj->model_name,
                'drum_year' => $obj->drum_year,
                'drum_origin' => $obj->drum_origin,
                'shop_id' => $obj->shop_id
            ));
        } 
    }
}