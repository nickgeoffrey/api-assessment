<?php

namespace Database\Seeders;

use App\Models\Guitar;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;

class GuitarSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run() {
        $json_file = File::get('database/data/guitar-data.json');
        DB::table('guitars')->delete();
        $data = json_decode($json_file);
        foreach ($data as $obj) {
            Guitar::create(array(
                'brand_name' => $obj->brand_name,
                'model_name' => $obj->model_name,
                'guitar_year' => $obj->guitar_year,
                'guitar_origin' => $obj->guitar_origin
            ));
        } 
    }
}
