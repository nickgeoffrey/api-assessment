<?php

namespace Database\Seeders;

use App\Models\Shop;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;

class ShopSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run() {
        $json_file = File::get('database/data/shop-data.json');
        DB::table('shops')->delete();
        $data = json_decode($json_file);
        foreach ($data as $obj) {
            Shop::create(array(
                'name' => $obj->name,
                'city' => $obj->city,
                'country' => $obj->country
            ));
        } 
    }
}
