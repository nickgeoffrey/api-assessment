<?php

namespace App\Http\Controllers;

use App\Models\Guitar;
use App\Models\Shop;
use App\Models\Drum;
use Illuminate\Http\Request;
use Validator;

class ApiController extends Controller

//Guitars
{
    public function createGuitar(Request $request) {
        $validator = Validator::make($request->all(), [
            'brand_name' => 'required',
            'model_name' => 'required',
            'guitar_year' => 'required',
            'guitar_origin' => 'required',
            'shop_id' => 'required'
        ]);
    
        if ($validator->fails()) {
            return response()->json(['message' => $validator->errors()], 403);
        } else {
            Guitar::create($request->all());
            return response()->json(['message' => 'Guitar created.'], 201);
        }
    }

    public function updateGuitar(Request $request, $id) {
        $guitars = Guitar::query();
        if ($guitars->where('id', $id)->exists()) {
            $guitar = $guitars->find($id);
            $guitar->brand_name = is_null($request->brand_name) ? $guitar->brand_name : $request->brand_name;
            $guitar->model_name = is_null($request->model_name) ? $guitar->model_name : $request->model_name;
            $guitar->guitar_year = is_null($request->guitar_year) ? $guitar->guitar_year : $request->guitar_year;
            $guitar->guitar_origin = is_null($request->guitar_origin) ? $guitar->guitar_origin : $request->guitar_origin;
            $guitar->save();
            return response()->json(['message' => 'Guitar updated.'], 200);
        } else {
            return response()->json(['message' => 'Guitar not found.'], 404);
        }
    }

    public function deleteGuitar($id) {
        $guitars = Guitar::query();
        if ($guitars->where('id', $id)->exists()) {
            $guitar = $guitars->find($id);
            $guitar->delete();
            return response()->json(['message' => 'Guitar deleted.'], 202);
        } else {
            return response()->json(['message' => 'Guitar not found.'], 404);
        }
    }

    public function getAllGuitars(Request $request)
    {
        $guitars = Guitars::query();
        if ($request->get('brand_name')) {
            $guitars->where('brand_name', '=', $request->get('brand_name'))->get();
        }
        return $guitars->get();
    }
    
    public function getGuitar($id) {
        $guitars = Guitar::query();
        if ($guitars->where('id', $id)->exists()) {
            $guitar = $guitars->where('id', $id)->get();
            return response($guitar, 200);
        } else {
            return response()->json(['message' => 'Guitar not found.'], 404);
        }
    }


    //Drums
    
        public function createDrum(Request $request) {
            $validator = Validator::make($request->all(), [
                'brand_name' => 'required',
                'model_name' => 'required',
                'drum_year' => 'required',
                'drum_origin' => 'required',
                'shop_id' => 'required'
            ]);
        
            if ($validator->fails()) {
                return response()->json(['message' => $validator->errors()], 403);
            } else {
                Drum::create($request->all());
                return response()->json(['message' => 'Drum created.'], 201);
            }
        }
    
        public function updateDrum(Request $request, $id) {
            $drums = Drum::query();
            if ($drums->where('id', $id)->exists()) {
                $drum = $drums->find($id);
                $drum->brand_name = is_null($request->brand_name) ? $drum->brand_name : $request->brand_name;
                $drum->model_name = is_null($request->model_name) ? $drum->model_name : $request->model_name;
                $drum->drum_year = is_null($request->drum_year) ? $drum->drum_year : $request->drum_year;
                $drum->drum_origin = is_null($request->drum_origin) ? $drum->drum_origin : $request->drum_origin;
                $drum->save();
                return response()->json(['message' => 'Drum updated.'], 200);
            } else {
                return response()->json(['message' => 'Drum not found.'], 404);
            }
        }
    
        public function deleteDrum($id) {
            $drums = Drum::query();
            if ($drums->where('id', $id)->exists()) {
                $drum = $drums->find($id);
                $drum->delete();
                return response()->json(['message' => 'Drum deleted.'], 202);
            } else {
                return response()->json(['message' => 'Drum not found.'], 404);
            }
        }
    
        public function getAllDrums(Request $request)
        {
            $drums = Drums::query();
            if ($request->get('brand_name')) {
                $drums->where('brand_name', '=', $request->get('brand_name'))->get();
            }
            return $drums->get();
        }
        
        public function getDrum($id) {
            $drums = Drum::query();
            if ($drums->where('id', $id)->exists()) {
                $drum = $drums->where('id', $id)->get();
                return response($drum, 200);
            } else {
                return response()->json(['message' => 'Drum not found.'], 404);
            }
        }



    //Shops    
    public function getAllShops(Request $request) {
        return Shop::with(['guitars'])->get();
    } 
}